# Ime aplikacije

BrickStock

## Kaj aplikacija dela?

Uporabnik naloži podatke, ki jih lahko filtrira in nato izvozi v JSON ali XML.

## Kako zagnati aplikacijo?

1. Odpri VS Code
2. Namesti razširitev **Live Server** (če je še nimaš)
3. Desni klik na `lego.html` → **Open with Live Server**
4. Aplikacija se odpre v brskalniku

## Kako uporabljati?

1. Klikni na naloži podatke.
2. Izberi željen filter.
3. Nato podatke iz željenega filtra izvozi v željen format.

## Tehnologije

HTML,CSS,JavaScript,XML parsing z DOMParser
